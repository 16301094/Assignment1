package edu.bjtu.ee4j.service;

import edu.bjtu.ee4j.domain.Member;
import edu.bjtu.ee4j.repository.MemberRepository;
//import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




@Service
public class MemberServiceImpl implements MemberService {

    private MemberRepository memberRepository;
    
    @Autowired
    public void setMemberRepository(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }
    
    @Override
    public Iterable<Member> getAllMembers() {
        return this.memberRepository.findAll();
    }
    
    @Override
    public Member getMemberById(Integer mid) {
        return this.memberRepository.findById(mid).orElse(null);
    }
    
    @Override
    public Member saveMember(Member member) {
        return this.memberRepository.save(member);
    }
    
    @Override
    public void deleteMember(Integer mid) {
        this.memberRepository.deleteById(mid);
    }

    @Override
    public Member getMemberByMobileNumber(String mobileNumber){return this.memberRepository.findByMobileNumber(mobileNumber);}

    @Override
    public Iterable<Member> getAllMembersByInstructor(int instructor_id){return this.memberRepository.findAllByInstructor(instructor_id);}
}
