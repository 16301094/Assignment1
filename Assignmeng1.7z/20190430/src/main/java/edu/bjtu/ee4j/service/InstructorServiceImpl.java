package edu.bjtu.ee4j.service;

import edu.bjtu.ee4j.domain.Instructor;
import edu.bjtu.ee4j.repository.InstructorRepository;

//import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InstructorServiceImpl implements InstructorService {

    private InstructorRepository instructorRepository;

    @Autowired
    public void setInstructorRepository(InstructorRepository instructorRepository) {
        this.instructorRepository = instructorRepository;
    }

    @Override
    public Iterable<Instructor> getAllInstructors() {
        return this.instructorRepository.findAll();
    }

    @Override
    public Instructor getInstructorById(Integer id) {
        return this.instructorRepository.findById(id).orElse(null);
    }

    @Override
    public Instructor saveInstructor(Instructor instructor) {
        return this.instructorRepository.save(instructor);
    }

    @Override
    public void deleteInstructor(Integer id) {
        this.instructorRepository.deleteById(id);
    }

}
