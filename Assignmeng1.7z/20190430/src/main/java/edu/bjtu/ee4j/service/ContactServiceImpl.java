package edu.bjtu.ee4j.service;

import edu.bjtu.ee4j.domain.Contact;
import edu.bjtu.ee4j.repository.ContactRepository;

//import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class ContactServiceImpl implements ContactService {

    private ContactRepository contactRepository;
    
    @Autowired
    public void setContactRepository(ContactRepository contactRepository) {
        this.contactRepository = contactRepository;
    }
    
    @Override
    public Iterable<Contact> getAllContacts() {
        return this.contactRepository.findAll();
    }
    
    @Override
    @Cacheable("contacts")
    public Contact getContactById(Integer id) {
        simulateSlowService();
        System.out.println("contact:"+id);
        return this.contactRepository.findById(id).orElse(null);
    }
    
    @Override
    public Contact saveContact(Contact contact) {
        return this.contactRepository.save(contact);
    }
    
    @Override
    public void deleteContact(Integer id) {
        this.contactRepository.deleteById(id);
    }

    // Don't do this at home
    private void simulateSlowService() {
        try {
            long time = 2000L;
            Thread.sleep(time);
            System.out.print("未经过缓存 sleep 2s\t:");
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
    }
    
}
