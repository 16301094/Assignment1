package edu.bjtu.ee4j.controller;

import edu.bjtu.ee4j.domain.Member;
import edu.bjtu.ee4j.service.MemberService;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MemberController {
    private MemberService memberService;

    @Autowired
    public void setMemberService(MemberService memberService) {
        this.memberService = memberService;
    }

    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String registerForm(Member member) {
        return "register";
    }


    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String registerForm(@Valid Member member, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("register", "member");
            return "register";
        }

        this.memberService.saveMember(member);
        return "redirect:/login";
    }

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String loginForm() {
        return "login";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String loginForm(@Valid String mobileNumber) {
        Member m = this.memberService.getMemberByMobileNumber(mobileNumber);
        if (m != null) {

            return "redirect:/member/"+m.getId();
        }

        return "login";
    }

    @RequestMapping(value = "/member/{id}", method = RequestMethod.GET)
    public String memberForm(@PathVariable Integer id,Model model) {
        model.addAttribute("member", this.memberService.getMemberById(id));
        return "profile";

    }

    @RequestMapping(value = "member/edit/{id}")
    public String editMember(@PathVariable Integer id, Model model) {
        model.addAttribute("member", this.memberService.getMemberById(id));
        return "edit";
    }

    @RequestMapping(value = "member/update", method = RequestMethod.POST)
    public String updateMember(Member member) {
        System.out.println("Member ID: " + member.getId());
        this.memberService.saveMember(member);
        return "redirect:/member/" + member.getId();
    }
}
