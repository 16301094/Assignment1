package edu.bjtu.ee4j.service;

import edu.bjtu.ee4j.domain.Gym;

public interface GymService {
    Iterable<Gym> getAllGyms();
    Gym getGymById(Integer gid);
    Gym saveGym(Gym gym);
    void deleteGym(Integer gid);
}
