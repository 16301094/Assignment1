package edu.bjtu.ee4j.repository;

import edu.bjtu.ee4j.domain.Member;
import org.springframework.data.repository.CrudRepository;



public interface MemberRepository extends CrudRepository<Member, Integer>{
    Member findByMobileNumber(String mobileNumber);
    Iterable<Member> findAllByInstructor(int instructor);
}

