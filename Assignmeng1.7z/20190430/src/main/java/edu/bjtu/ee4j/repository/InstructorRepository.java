package edu.bjtu.ee4j.repository;

import edu.bjtu.ee4j.domain.Instructor;
import edu.bjtu.ee4j.domain.Member;
import org.springframework.data.repository.CrudRepository;

public interface InstructorRepository extends CrudRepository<Instructor, Integer>{
}

