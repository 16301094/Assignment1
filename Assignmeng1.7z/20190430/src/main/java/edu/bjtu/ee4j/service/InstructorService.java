package edu.bjtu.ee4j.service;

import edu.bjtu.ee4j.domain.Instructor;

public interface InstructorService {
    Iterable<Instructor> getAllInstructors();
    Instructor getInstructorById(Integer id);
    Instructor saveInstructor(Instructor instructor);
    void deleteInstructor(Integer id);
}
