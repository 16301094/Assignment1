package edu.bjtu.ee4j.controller;

import edu.bjtu.ee4j.domain.Gym;
import edu.bjtu.ee4j.service.GymService;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/gyms")
public class GymController {
    private GymService gymService;

    @Autowired
    public void setGymService(GymService gymService) {
        this.gymService = gymService;
    }

    @RequestMapping(value = { "", "/" })
    public String index(Model model) {
        model.addAttribute("gyms", this.gymService.getAllGyms());
        return "gyms/index";
    }





    @RequestMapping(value = "/view/{gid}")
    public String viewGym(@PathVariable Integer gid, Model model) {
        model.addAttribute("gym", this.gymService.getGymById(gid));
        return "gyms/view";
    }





}