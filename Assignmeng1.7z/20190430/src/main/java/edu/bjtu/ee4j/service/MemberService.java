package edu.bjtu.ee4j.service;

import edu.bjtu.ee4j.domain.Member;

public interface MemberService {
    Iterable<Member> getAllMembers();
    Member getMemberById(Integer mid);
    Member saveMember(Member member);
    void deleteMember(Integer mid);
    Member getMemberByMobileNumber(String mobileNumber);
    Iterable<Member> getAllMembersByInstructor(int instructor);
}
