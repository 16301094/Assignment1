package edu.bjtu.ee4j.controller;

import edu.bjtu.ee4j.domain.Instructor;
import edu.bjtu.ee4j.domain.Member;
import edu.bjtu.ee4j.service.InstructorService;
import edu.bjtu.ee4j.service.MemberService;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/instructors")
public class InstructorController {
    private InstructorService instructorService;
    private MemberService memberService;
    @Autowired
    public void setInstructorService(InstructorService instructorService) {
        this.instructorService = instructorService;
    }
    @Autowired
    public void setMemberService(MemberService memberService) {
        this.memberService = memberService;
    }

    @RequestMapping(value = { "", "/" })
    public String index(Model model) {
        model.addAttribute("instructors", this.instructorService.getAllInstructors());
        return "instructors/index";
    }

    @RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
    public String instructorForm(@PathVariable Integer id,Model model) {
        model.addAttribute("instructor", this.instructorService.getInstructorById(id));
        Iterable<Member> m;
        try{
            m=this.memberService.getAllMembersByInstructor(id);
        } catch (Exception e){m=null;}
        model.addAttribute("members",m);
        return "instructors/view";

    }


}