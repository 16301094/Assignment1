package edu.bjtu.ee4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class SpringMvcCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcCrudApplication.class, args);
	}

}
