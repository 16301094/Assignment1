package edu.bjtu.ee4j.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;
import javax.validation.constraints.NotEmpty;

@Entity
public class Gym {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer gid;
    @NotEmpty(message = "First Name is required.")
    @Size(min = 2, message = "Name must be at least 2 characters.")
    private String name;
    @NotEmpty(message = "Address is required.")
    private String address;
    @NotEmpty(message = "capacity is required.")
    private int capacity;



    public Integer getId() {
        return gid;
    }

    public void setId(Integer gid) {
        this.gid = gid;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCapacity(int capacity) {this.capacity = capacity;}

    public int getCapacity() {return capacity;}

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }


}
