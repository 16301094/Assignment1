package edu.bjtu.ee4j.service;

import edu.bjtu.ee4j.domain.Gym;
import edu.bjtu.ee4j.repository.GymRepository;

//import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GymServiceImpl implements GymService {

    private GymRepository GymRepository;

    @Autowired
    public void setGymRepository(GymRepository GymRepository) {
        this.GymRepository = GymRepository;
    }

    @Override
    public Iterable<Gym> getAllGyms() {
        return this.GymRepository.findAll();
    }

    @Override
    public Gym getGymById(Integer id) {
        return this.GymRepository.findById(id).orElse(null);
    }

    @Override
    public Gym saveGym(Gym gym) {
        return this.GymRepository.save(gym);
    }

    @Override
    public void deleteGym(Integer id) {
        this.GymRepository.deleteById(id);
    }

}