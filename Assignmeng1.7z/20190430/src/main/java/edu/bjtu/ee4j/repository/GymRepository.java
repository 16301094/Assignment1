package edu.bjtu.ee4j.repository;

import edu.bjtu.ee4j.domain.Gym;
import org.springframework.data.repository.CrudRepository;

public interface GymRepository extends CrudRepository<Gym, Integer>{

}

